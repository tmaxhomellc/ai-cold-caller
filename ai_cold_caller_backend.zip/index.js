// AI Cold Caller backend entry point
